import { Request, Response, NextFunction } from 'express';

export type UserRole = 'PRINCIPAL' | 'BURSAR' | 'TEACHER' | 'STUDENT_PARENT';

export interface AuthUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  roleTitle: string;
  department?: string;
  admissionNo?: string;
  tscNumber?: string;
  permissions: string[];
}

export const DEMO_USERS: Record<string, { password: string; user: AuthUser }> = {
  principal: {
    password: 'password123',
    user: {
      id: 'usr-principal-01',
      username: 'principal',
      name: 'Mrs. Margaret M. Musyoka, OGW',
      role: 'PRINCIPAL',
      roleTitle: 'Chief Principal & Secretary to Board of Management',
      permissions: ['ALL', 'APPROVE_RESULTS', 'BROADCAST_SMS', 'MANAGE_STAFF', 'VIEW_AUDIT_LOGS']
    }
  },
  bursar: {
    password: 'password123',
    user: {
      id: 'usr-bursar-02',
      username: 'bursar',
      name: 'Mr. Julius Mutua',
      role: 'BURSAR',
      roleTitle: 'Senior Bursar & Head of Accounts',
      permissions: ['VIEW_FINANCES', 'RECONCILE_PAYMENTS', 'MANAGE_FEES', 'VIEW_SMS_LOGS', 'CLEAR_VOUCHERS']
    }
  },
  teacher: {
    password: 'password123',
    user: {
      id: 'usr-teacher-03',
      username: 'teacher',
      name: 'Mr. Dennis Ochieng',
      role: 'TEACHER',
      roleTitle: 'HOD Mathematics & Form 3 West Class Teacher',
      department: 'Mathematics',
      tscNumber: 'TSC/412093/K',
      permissions: ['ENTER_MARKS', 'EDIT_CAT_SCORES', 'VIEW_BROADSHEET', 'PRINT_REPORTS']
    }
  },
  parent: {
    password: 'password123',
    user: {
      id: 'usr-parent-04',
      username: 'parent',
      name: 'Patrick Musyoki (Parent) / Brian Mutua',
      role: 'STUDENT_PARENT',
      roleTitle: 'Parent & Student Portal (Form 3 West)',
      admissionNo: 'NHS/3412/2023',
      permissions: ['VIEW_OWN_REPORT', 'PAY_FEES', 'VIEW_OWN_STATEMENT', 'DOWNLOAD_SLIPS']
    }
  }
};

// Express Middleware for Role-Based Authorization
export function requireRole(allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Check Authorization header or custom role override header
    const authHeader = req.headers.authorization;
    const roleHeader = req.headers['x-user-role'] as UserRole;

    let userRole: UserRole | undefined = roleHeader;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      // Decode simulated token e.g. "token-principal"
      const matchedKey = Object.keys(DEMO_USERS).find(k => token.includes(k));
      if (matchedKey) {
        userRole = DEMO_USERS[matchedKey].user.role;
      }
    }

    // Default to STUDENT_PARENT if unauthenticated
    if (!userRole) {
      userRole = 'STUDENT_PARENT';
    }

    if (allowedRoles.includes(userRole) || userRole === 'PRINCIPAL') {
      return next();
    }

    return res.status(403).json({
      success: false,
      error: 'Access Denied: Your account role does not have permission to execute this administrative action.',
      requiredRoles: allowedRoles,
      currentRole: userRole
    });
  };
}
