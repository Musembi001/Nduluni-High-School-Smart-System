import React, { useState, useEffect } from 'react';
import { Student, PaymentTransaction } from '../types';
import { SCHOOL_INFO, INITIAL_STUDENTS, MOCK_FEE_STRUCTURE, INITIAL_TRANSACTIONS } from '../data/mockData';
import { 
  CreditCard, 
  Smartphone, 
  Building2, 
  CheckCircle2, 
  Printer, 
  Download, 
  Search, 
  AlertCircle, 
  FileText, 
  Receipt, 
  ArrowRight,
  ShieldCheck,
  Check,
  RefreshCw,
  MessageSquare,
  Radio
} from 'lucide-react';

interface FeePaymentSystemProps {
  initialAdmissionNo?: string;
  onNavigateToPortal: () => void;
}

export const FeePaymentSystem: React.FC<FeePaymentSystemProps> = ({ 
  initialAdmissionNo,
  onNavigateToPortal 
}) => {
  const [studentsList, setStudentsList] = useState<Student[]>(INITIAL_STUDENTS);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>(INITIAL_TRANSACTIONS);
  const [smsLogs, setSmsLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'pay' | 'sms_logs'>('pay');

  const [activeAdmissionNo, setActiveAdmissionNo] = useState(
    initialAdmissionNo || studentsList[0]?.admissionNo || 'NHS/3412/2023'
  );

  const [paymentChannel, setPaymentChannel] = useState<'mpesa' | 'bank' | 'card'>('mpesa');
  const [parentPhone, setParentPhone] = useState('0724891230');
  const [paymentAmount, setPaymentAmount] = useState<string>('14500');
  const [bankRefCode, setBankRefCode] = useState('');
  
  // M-Pesa STK Push Simulation State
  const [isProcessingStk, setIsProcessingStk] = useState(false);
  const [showStkPrompt, setShowStkPrompt] = useState(false);
  const [mpesaPin, setMpesaPin] = useState('');
  const [lastReceipt, setLastReceipt] = useState<PaymentTransaction | null>(null);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);
  const [checkoutId, setCheckoutId] = useState<string>('');

  // Fetch initial data from server
  const loadServerData = async () => {
    try {
      // 1. Fetch Students
      const stdRes = await fetch('/api/v1/students');
      if (stdRes.ok) {
        const stdJson = await stdRes.json();
        if (stdJson.data && stdJson.data.length > 0) {
          setStudentsList(stdJson.data.map((s: any) => ({
            id: s.id,
            admissionNo: s.admissionNo,
            fullName: s.fullName,
            form: s.form,
            stream: s.stream,
            house: s.house,
            guardianName: s.guardianName,
            guardianPhone: s.guardianPhone,
            kcpeMarks: s.kcpeMarks,
            currentTermBalance: s.currentTermBalance,
            attendanceRate: s.attendanceRate,
            classTeacher: s.classTeacher
          })));
        }
      }

      // 2. Fetch Transactions
      const txRes = await fetch('/api/v1/payments/transactions');
      if (txRes.ok) {
        const txJson = await txRes.json();
        if (txJson.data) {
          setTransactions(txJson.data);
        }
      }

      // 3. Fetch SMS Logs
      const smsRes = await fetch('/api/v1/sms/logs');
      if (smsRes.ok) {
        const smsJson = await smsRes.json();
        if (smsJson.data) {
          setSmsLogs(smsJson.data);
        }
      }
    } catch (e) {
      console.log('Using local client state for fee payments');
    }
  };

  useEffect(() => {
    loadServerData();
  }, []);

  const currentStudent = studentsList.find(s => s.admissionNo === activeAdmissionNo) || studentsList[0];

  const handleAdmissionChange = (admNo: string) => {
    setActiveAdmissionNo(admNo);
    const std = studentsList.find(s => s.admissionNo === admNo);
    if (std) {
      setPaymentAmount(std.currentTermBalance > 0 ? std.currentTermBalance.toString() : '5000');
      setParentPhone(std.guardianPhone);
    }
  };

  const initiatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(paymentAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert("Please enter a valid amount to pay.");
      return;
    }

    if (paymentChannel === 'mpesa') {
      if (!parentPhone || parentPhone.length < 9) {
        alert("Please provide a valid Safaricom phone number.");
        return;
      }
      setIsProcessingStk(true);

      try {
        // Real Backend STK Push Call
        const res = await fetch('/api/v1/payments/mpesa/stkpush', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phoneNumber: parentPhone,
            amount: amountNum,
            admissionNo: currentStudent.admissionNo
          })
        });

        const json = await res.json();
        if (json.success) {
          setCheckoutId(json.data.checkoutRequestId);
          setShowStkPrompt(true);
        } else {
          alert(`STK Push failed: ${json.error}`);
        }
      } catch (err) {
        // Fallback simulation
        setCheckoutId(`ws_CO_${Date.now()}`);
        setShowStkPrompt(true);
      } finally {
        setIsProcessingStk(false);
      }
    } else if (paymentChannel === 'bank') {
      if (!bankRefCode.trim()) {
        alert("Please enter the bank deposit slip reference code.");
        return;
      }

      try {
        const res = await fetch('/api/v1/payments/bank-deposit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            admissionNo: currentStudent.admissionNo,
            amount: amountNum,
            bankReference: bankRefCode.trim().toUpperCase(),
            branch: 'Co-op Bank Machakos'
          })
        });

        if (res.ok) {
          const json = await res.json();
          setLastReceipt(json.data.transaction);
          setPaymentSuccessMsg(`Bank deposit slip ${bankRefCode} validated. KES ${amountNum.toLocaleString()} credited to ${currentStudent.fullName}.`);
          loadServerData();
        }
      } catch (err) {
        alert("Server communication error. Please try again.");
      }
    } else {
      // Card Payment
      confirmCallbackDirect('Credit/Debit Card', `CARD-${Math.random().toString(36).substring(2, 9).toUpperCase()}`);
    }
  };

  const confirmMpesaPrompt = async () => {
    setShowStkPrompt(false);
    const amountNum = parseFloat(paymentAmount);

    try {
      // Real Webhook Confirmation to Backend
      const res = await fetch('/api/v1/payments/mpesa/callback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          checkoutRequestId: checkoutId,
          admissionNo: currentStudent.admissionNo,
          amount: amountNum,
          phoneNumber: parentPhone
        })
      });

      if (res.ok) {
        const json = await res.json();
        setLastReceipt(json.data.transaction);
        setPaymentSuccessMsg(`Payment of KES ${amountNum.toLocaleString()} confirmed via M-Pesa ${json.data.transaction.referenceCode}! SMS receipt dispatched.`);
        await loadServerData();
      }
    } catch (e) {
      confirmCallbackDirect('M-PESA', `TK${Math.random().toString(36).substring(2, 10).toUpperCase()}`);
    }
    setMpesaPin('');
  };

  const confirmCallbackDirect = (method: 'M-PESA' | 'Bank Deposit' | 'Credit/Debit Card', refCode: string) => {
    const amountNum = parseFloat(paymentAmount);
    const newReceiptNo = `NHS-REC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTxn: PaymentTransaction = {
      id: `txn-${Date.now()}`,
      receiptNo: newReceiptNo,
      admissionNo: currentStudent.admissionNo,
      studentName: currentStudent.fullName,
      amount: amountNum,
      paymentMethod: method,
      referenceCode: refCode,
      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      term: 'Term 1, 2026',
      status: 'Completed',
      receivedBy: method === 'M-PESA' ? 'Automated M-Pesa Gateway' : 'School Bursar (Verified)'
    };

    const updatedStudents = studentsList.map(s => {
      if (s.admissionNo === currentStudent.admissionNo) {
        const newBal = Math.max(0, s.currentTermBalance - amountNum);
        return { ...s, currentTermBalance: newBal };
      }
      return s;
    });

    setStudentsList(updatedStudents);
    setTransactions([newTxn, ...transactions]);
    setLastReceipt(newTxn);
    setPaymentSuccessMsg(`Payment of KES ${amountNum.toLocaleString()} successfully received and reconciled for ${currentStudent.fullName}!`);
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="no-print bg-stone-900 text-white rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-sm">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-stone-800 text-emerald-400 text-xs font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>MoE Verified Automated School Fees Reconciliation Engine</span>
              <span className="text-stone-500">·</span>
              <span className="text-amber-300">Daraja 2.0 Webhook Connected</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-display">
              Online Fee Payment & Statement System
            </h1>
            <p className="text-stone-300 text-sm max-w-2xl font-sans">
              Instant digital fee clearance via Lipa na M-Pesa Paybill <strong className="text-white font-mono">{SCHOOL_INFO.mpesaPaybill}</strong> or direct bank deposit. Official Ministry-compliant receipts generated immediately.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab(activeTab === 'pay' ? 'sms_logs' : 'pay')}
              className="px-3.5 py-2.5 text-xs font-semibold text-stone-200 bg-stone-800 hover:bg-stone-700 rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-sky-400" />
              <span>{activeTab === 'pay' ? `View Parent SMS Logs (${smsLogs.length})` : 'Return to Payment Portal'}</span>
            </button>

            <button
              onClick={onNavigateToPortal}
              className="px-4 py-2.5 text-xs font-semibold text-stone-900 bg-white hover:bg-stone-100 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>View Academic Portal</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Heraldic Kenyan Colors Ribbon */}
        <div className="absolute bottom-0 left-0 right-0 h-1 flex">
          <div className="w-1/3 bg-black"></div>
          <div className="w-1/3 bg-rose-700"></div>
          <div className="w-1/3 bg-emerald-700"></div>
        </div>
      </div>

      {paymentSuccessMsg && (
        <div className="no-print p-4 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-medium">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{paymentSuccessMsg}</span>
          </div>
          <button 
            onClick={() => setPaymentSuccessMsg(null)}
            className="text-xs text-emerald-700 hover:text-emerald-900 font-semibold cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* VIEW 1: Main Fee Payment Engine */}
      {activeTab === 'pay' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Interactive Payment Engine */}
          <div className="no-print lg:col-span-7 space-y-6">
            <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm space-y-6">
              <div className="space-y-1">
                <h2 className="text-lg font-bold font-display text-stone-900">
                  1. Select Student & Term Account
                </h2>
                <p className="text-xs text-stone-500">Pick an enrolled scholar to fetch current term balance automatically</p>
              </div>

              {/* Quick Student Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {studentsList.map((std) => (
                  <button
                    key={std.id}
                    onClick={() => handleAdmissionChange(std.admissionNo)}
                    className={`p-3 rounded-lg text-left border transition-all cursor-pointer ${
                      activeAdmissionNo === std.admissionNo
                        ? 'border-rose-900 bg-rose-50/50 shadow-sm'
                        : 'border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <p className="text-xs font-bold text-stone-900 truncate">{std.fullName}</p>
                    <p className="text-[11px] font-mono text-stone-500">{std.admissionNo}</p>
                    <p className="text-xs font-semibold mt-1">
                      {std.currentTermBalance === 0 ? (
                        <span className="text-emerald-700">Cleared</span>
                      ) : (
                        <span className="text-rose-900">KES {std.currentTermBalance.toLocaleString()}</span>
                      )}
                    </p>
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-stone-100">
                <h2 className="text-lg font-bold font-display text-stone-900 mb-1">
                  2. Choose Payment Channel
                </h2>
                <p className="text-xs text-stone-500 mb-4">Official accredited payment channels for Nduluni High School</p>

                {/* Channel Selector */}
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentChannel('mpesa')}
                    className={`p-3 rounded-lg border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                      paymentChannel === 'mpesa'
                        ? 'border-emerald-700 bg-emerald-50 text-emerald-950 font-bold shadow-sm'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Smartphone className="w-5 h-5 text-emerald-700" />
                    <span className="text-xs">Lipa na M-PESA</span>
                    <span className="text-[10px] text-emerald-800 font-mono">Paybill 522123</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentChannel('bank')}
                    className={`p-3 rounded-lg border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                      paymentChannel === 'bank'
                        ? 'border-rose-900 bg-rose-50 text-rose-950 font-bold shadow-sm'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Building2 className="w-5 h-5 text-rose-900" />
                    <span className="text-xs">Co-op Bank</span>
                    <span className="text-[10px] text-stone-500">Direct Deposit</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentChannel('card')}
                    className={`p-3 rounded-lg border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                      paymentChannel === 'card'
                        ? 'border-sky-800 bg-sky-50 text-sky-950 font-bold shadow-sm'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-sky-800" />
                    <span className="text-xs">Debit / Card</span>
                    <span className="text-[10px] text-stone-500">Visa / Mastercard</span>
                  </button>
                </div>
              </div>

              {/* Payment Form */}
              <form onSubmit={initiatePayment} className="space-y-4 pt-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Student Admission Number
                    </label>
                    <input
                      type="text"
                      value={activeAdmissionNo}
                      onChange={(e) => setActiveAdmissionNo(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-stone-300 focus:outline-none focus:ring-1 focus:ring-rose-900 bg-stone-50"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Amount to Pay (KES)
                    </label>
                    <input
                      type="number"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      required
                      min="100"
                      className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-stone-300 focus:outline-none focus:ring-1 focus:ring-rose-900"
                    />
                  </div>
                </div>

                {paymentChannel === 'mpesa' && (
                  <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-950">M-PESA Express (STK Push Gateway)</span>
                      <span className="text-[11px] font-mono text-emerald-800">Paybill: 522123 · Acc: {currentStudent.admissionNo}</span>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">
                        Parent / Guardian Safaricom Phone Number
                      </label>
                      <input
                        type="tel"
                        value={parentPhone}
                        onChange={(e) => setParentPhone(e.target.value)}
                        placeholder="e.g. 0724891230"
                        required
                        className="w-full px-3 py-2 text-xs font-mono rounded border border-stone-300 bg-white"
                      />
                      <p className="text-[11px] text-stone-500 mt-1">
                        Transmits a real-time Safaricom Daraja STK Push prompt to your handset. Enter PIN to complete.
                      </p>
                    </div>
                  </div>
                )}

                {paymentChannel === 'bank' && (
                  <div className="p-4 bg-rose-50/70 border border-rose-200 rounded-lg space-y-3 text-xs">
                    <div className="font-bold text-rose-950">School Banking Particulars:</div>
                    <div className="space-y-1 font-mono text-stone-700">
                      <p>Bank: {SCHOOL_INFO.bankAccount.bankName}</p>
                      <p>Branch: {SCHOOL_INFO.bankAccount.branch}</p>
                      <p>A/C No: <strong>{SCHOOL_INFO.bankAccount.accountNumber}</strong></p>
                      <p>A/C Name: {SCHOOL_INFO.bankAccount.accountName}</p>
                    </div>
                    <div>
                      <label className="block font-medium text-stone-700 mb-1">
                        Bank Deposit Slip Voucher / Serial Code
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. COOP-DEP-94182"
                        value={bankRefCode}
                        onChange={(e) => setBankRefCode(e.target.value)}
                        className="w-full px-3 py-2 text-xs font-mono rounded border border-stone-300 bg-white"
                      />
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isProcessingStk}
                  className="w-full py-3 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-700 rounded-lg transition-colors shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isProcessingStk ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Transmitting Daraja STK Prompt to {parentPhone}...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>
                        Pay KES {parseFloat(paymentAmount || '0').toLocaleString()} for {currentStudent.fullName}
                      </span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Official Fee Structure Accordion */}
            <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold font-display text-stone-900">
                    Approved Ministry of Education Fee Vote Heads (2026)
                  </h3>
                  <p className="text-[11px] text-stone-500">County Extra-County Boarding Public School Guidelines</p>
                </div>
                <span className="text-xs font-bold text-rose-900 font-mono">Term 1 Obligation</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500 font-medium">
                      <th className="py-2">Vote Head Particulars</th>
                      <th className="py-2 text-right">Term 1</th>
                      <th className="py-2 text-right">Term 2</th>
                      <th className="py-2 text-right">Term 3</th>
                      <th className="py-2 text-right">Annual Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {MOCK_FEE_STRUCTURE.filter(f => f.category === 'Parent Obligation').map((item) => (
                      <tr key={item.id} className="hover:bg-stone-50">
                        <td className="py-2 text-stone-800">{item.voteHead}</td>
                        <td className="py-2 text-right font-mono">KES {item.term1.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono text-stone-500">KES {item.term2.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono text-stone-500">KES {item.term3.toLocaleString()}</td>
                        <td className="py-2 text-right font-mono font-semibold">KES {item.approvedMoE.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-stone-300 font-bold text-stone-900 bg-stone-50">
                      <td className="py-2.5">Total Boarding & Parent Levies</td>
                      <td className="py-2.5 text-right font-mono text-rose-950">KES 29,900</td>
                      <td className="py-2.5 text-right font-mono">KES 17,800</td>
                      <td className="py-2.5 text-right font-mono">KES 9,800</td>
                      <td className="py-2.5 text-right font-mono">KES 57,500</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>

          {/* Right Column: Statement & Printable Official Receipt */}
          <div className="lg:col-span-5 space-y-6">
            {/* Official Printable Receipt Card */}
            <div className="bg-white rounded-xl border border-stone-200 p-6 shadow-sm space-y-6" id="printable-receipt">
              <div className="flex items-center justify-between border-b border-stone-200 pb-4">
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-rose-950" />
                  <span className="font-bold text-sm text-stone-900 font-display">Official School Receipt</span>
                </div>
                <button
                  onClick={handlePrintReceipt}
                  className="no-print px-3 py-1.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Receipt</span>
                </button>
              </div>

              {/* Receipt Preview Body */}
              <div className="p-4 bg-stone-50 border border-dashed border-stone-300 rounded-lg space-y-4 text-xs font-mono">
                <div className="text-center space-y-1 pb-3 border-b border-stone-200">
                  <h4 className="font-bold text-stone-900 text-sm font-display tracking-wider">{SCHOOL_INFO.name}</h4>
                  <p className="text-[10px] text-stone-600">BURSAR'S OFFICIAL CASH RECEIPT</p>
                  <p className="text-[10px] text-stone-500">P.O. Box 48 - 90130, Nduluni · MoE Code: 12314502</p>
                </div>

                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-stone-500">Receipt No:</span>
                    <span className="font-bold text-stone-900">{lastReceipt?.receiptNo || 'NHS-REC-2026-0891'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Date:</span>
                    <span>{lastReceipt?.date || '12 Jan 2026, 09:41 AM'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Student Name:</span>
                    <span className="font-bold text-stone-900">{lastReceipt?.studentName || currentStudent.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Admission No:</span>
                    <span className="font-bold text-stone-900">{lastReceipt?.admissionNo || currentStudent.admissionNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Payment Channel:</span>
                    <span className="text-emerald-800 font-semibold">{lastReceipt?.paymentMethod || 'M-PESA Paybill 522123'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">M-Pesa Reference:</span>
                    <span className="font-bold text-stone-900">{lastReceipt?.referenceCode || 'TK98XQ821P'}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-200 space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span>AMOUNT RECEIVED:</span>
                    <span className="text-rose-950 text-sm">
                      KES {(lastReceipt?.amount || 25000).toLocaleString()}.00
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px] text-stone-600">
                    <span>Remaining Term Balance:</span>
                    <span>KES {currentStudent.currentTermBalance.toLocaleString()}.00</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200 flex items-center justify-between text-[10px] text-stone-500">
                  <div>
                    <p>Certified by: Automated Gateway</p>
                    <p className="text-emerald-700 font-bold">STATUS: VALID & VERIFIED</p>
                  </div>
                  <div className="w-12 h-12 bg-white border border-stone-300 p-1 flex items-center justify-center text-[9px] text-stone-400 text-center leading-none">
                    [QR SEAL 123145]
                  </div>
                </div>
              </div>
            </div>

            {/* Past Transactions Ledger */}
            <div className="no-print bg-white rounded-xl border border-stone-200 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold font-display text-stone-900">
                  Recent Clearance Ledger
                </h3>
                <span className="text-xs text-stone-500">{transactions.length} records</span>
              </div>

              <div className="space-y-3">
                {transactions.slice(0, 4).map((txn) => (
                  <div 
                    key={txn.id}
                    onClick={() => setLastReceipt(txn)}
                    className="p-3 rounded-lg border border-stone-100 hover:border-stone-300 hover:bg-stone-50 transition-colors cursor-pointer flex items-center justify-between text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-stone-900">{txn.studentName}</span>
                        <span className="text-[10px] text-stone-500 font-mono">({txn.admissionNo})</span>
                      </div>
                      <p className="text-[11px] text-stone-500">
                        {txn.paymentMethod} · Ref: <strong className="text-stone-700 font-mono">{txn.referenceCode}</strong> · {txn.date}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold font-mono text-emerald-800 block">
                        KES {txn.amount.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-stone-400">View Receipt</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: Africa's Talking Parent SMS Gateway Logs */}
      {activeTab === 'sms_logs' && (
        <div className="bg-white rounded-xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-stone-200 pb-4">
            <div>
              <h2 className="text-xl font-bold font-display text-stone-900 flex items-center gap-2">
                <Radio className="w-5 h-5 text-emerald-600" />
                <span>Africa's Talking Parent SMS Delivery Logs</span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Real-time audit log of automated SMS confirmations dispatched to Safaricom, Airtel, and Telkom numbers.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('pay')}
              className="px-3 py-1.5 text-xs font-semibold text-rose-900 bg-rose-50 border border-rose-200 rounded cursor-pointer"
            >
              Back to Fees
            </button>
          </div>

          <div className="space-y-4">
            {smsLogs.length === 0 ? (
              <p className="text-xs text-stone-500 italic">No SMS dispatches yet. Complete a payment to trigger an SMS receipt.</p>
            ) : (
              smsLogs.map((sms) => (
                <div key={sms.id} className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-stone-900">{sms.recipientName}</span>
                      <span className="font-mono text-stone-600">({sms.recipientPhone})</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-900 border border-emerald-300">
                        {sms.status}
                      </span>
                    </div>
                    <span className="text-stone-400 font-mono text-[11px]">{sms.timestamp}</span>
                  </div>

                  <p className="text-stone-700 bg-white p-3 rounded border border-stone-200 font-mono text-[11px] leading-relaxed">
                    "{sms.message}"
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-stone-500 font-mono pt-1">
                    <span>Gateway: Africa's Talking Kenya (SMPP)</span>
                    <span>Cost: {sms.cost}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Simulated Safaricom M-Pesa STK Push Modal */}
      {showStkPrompt && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-stone-900 text-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-stone-700 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-emerald-600 flex items-center justify-center font-bold text-xs text-white">
                  M
                </div>
                <span className="font-bold text-sm tracking-wide">SIM Toolkit · Safaricom</span>
              </div>
              <span className="text-xs text-stone-400 font-mono">STK PUSH</span>
            </div>

            <div className="bg-stone-950 p-4 rounded-xl border border-stone-800 text-xs font-mono space-y-2 text-stone-200">
              <p className="leading-relaxed">
                Do you want to pay <strong className="text-emerald-400">KES {parseFloat(paymentAmount).toLocaleString()}</strong> to <strong className="text-white">NDULUNI HIGH SCHOOL</strong>?
              </p>
              <p className="text-stone-400">Paybill: 522123</p>
              <p className="text-stone-400">Account: {currentStudent.admissionNo}</p>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-stone-300">
                Enter M-PESA PIN:
              </label>
              <input
                type="password"
                maxLength={4}
                autoFocus
                placeholder="••••"
                value={mpesaPin}
                onChange={(e) => setMpesaPin(e.target.value)}
                className="w-full text-center text-lg tracking-widest px-3 py-2 rounded-lg bg-stone-800 border border-stone-700 text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowStkPrompt(false)}
                className="py-2 text-xs font-medium text-stone-400 hover:text-white bg-stone-800 hover:bg-stone-700 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmMpesaPrompt}
                className="py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow cursor-pointer"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
